// const mockData=[

// ];console.log[mockData];
 export function populatecards(mockData)
 {
     for(let i=0;i<mockData.length;i++){
    //  console.log(mockData[i].name);
    var cardContainer = document.createElement('div');
    cardContainer.setAttribute('class','dish-card');
    var imgElement=document.createElement('img');
    imgElement.setAttribute('class','dish-image');
    imgElement.setAttribute('src',mockData[i].feature_image);
    imgElement.setAttribute('alt','Restaurant Image');

    var restaurantName=document.createElement('div');
    restaurantName.setAttribute('class','dish-Name');
    if(mockData[i].feature_image==''){
        imgElement.setAttribute('src','./assets/restPlaceholder.jpg');
    }else{
        imgElement.setAttribute('src',mockData[i].feature_image);
    }
    restaurantName.appendChild(document.createTextNode(mockData[i].name));

    var restaurantDescription=document.createElement('div');
    restaurantDescription.setAttribute('class','description');
    restaurantDescription.appendChild(document.createTextNode(mockData[i].cuisines));

    var rating=document.createElement('div');
    rating.setAttribute('class','rating');
    rating.appendChild(document.createTextNode(mockData[i].rating));

    var iElement=document.createElement('i');
    iElement.setAttribute('class','fa fa-star');
    rating.appendChild(iElement);
    
    var review=document.createElement('div')
    review.setAttribute('class','review');
    review.appendChild(document.createTextNode(mockData[i].reviews+"Reviews"));

    cardContainer.appendChild(imgElement);
    cardContainer.appendChild(restaurantName);
    cardContainer.appendChild(restaurantDescription);
    cardContainer.appendChild(rating);
    cardContainer.appendChild(review);
    console.log(cardContainer);

    document.getElementById('menu-container').appendChild(cardContainer);
}
 }